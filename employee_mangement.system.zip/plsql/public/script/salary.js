
                // Function to calculate Net Salary
                function calculateNetSalary() {
                    const basicSalary = parseFloat(document.getElementById('basicSalary').value) || 0;
                    const deduction = parseFloat(document.getElementById('deduction').value) || 0;
                    const bonus = parseFloat(document.getElementById('bonus').value) || 0;
            
                    // Calculate net salary
                    const netSalary = basicSalary + bonus - deduction;
            
                    // Set net salary in the read-only input field
                    document.getElementById('netSalary').value = netSalary.toFixed(2); // Fixed to 2 decimal places
                }
            
                // Add event listeners to calculate net salary on input change
                document.getElementById('basicSalary').addEventListener('input', calculateNetSalary);
                document.getElementById('deduction').addEventListener('input', calculateNetSalary);
                document.getElementById('bonus').addEventListener('input', calculateNetSalary);     