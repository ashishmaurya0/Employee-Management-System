 // Wait until the DOM is fully loaded
 document.addEventListener('DOMContentLoaded', function() {
    // Select all delete buttons
    const deleteButtons = document.querySelectorAll('.delete-employee-btn');

    // Attach click event listeners to each button
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            // Prevent any default action
            event.preventDefault();

            // Get the employee ID from the button's data attribute
            const employeeId = this.getAttribute('data-employee-id');

            // Confirm before deleting
            if (confirm('Are you sure you want to delete this employee?')) {
                // Send DELETE request using Fetch API
                fetch(`/employees/${employeeId}`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        // Optionally, you can remove the employee row from the table without refreshing
                        this.closest('tr').remove();
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error deleting employee:', error);
                    alert('An error occurred while deleting the employee.');
                });
            }
        });
    });
});