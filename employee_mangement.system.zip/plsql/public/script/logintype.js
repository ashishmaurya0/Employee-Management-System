        // Function to change form action based on login type selection
        function changeAction() {
            const loginType = document.getElementById('loginType').value;
            const loginForm = document.getElementById('loginForm');

            // Set form action based on selected login type
            if (loginType === 'admin') {
                loginForm.action = '/admin/login'; // Admin login route
            } else if (loginType === 'user') {
                loginForm.action = '/login'; // User login route
            }
        }