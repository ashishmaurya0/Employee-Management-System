    // JavaScript to toggle sign-up prompt based on login type
    document.getElementById("loginType").addEventListener("change", function () {
        const signupPrompt = document.getElementById("signupPrompt");
        const emailField = document.getElementById("emailField");

        if (this.value === "admin") {
            emailField.style.display = "block";    // Hide email field for admin
            signupPrompt.style.display = "none";   // Hide sign-up prompt for admin
        } else {
            emailField.style.display = "block";    // Show email field for user
            signupPrompt.style.display = "block";   // Show sign-up prompt for user
        }
    });