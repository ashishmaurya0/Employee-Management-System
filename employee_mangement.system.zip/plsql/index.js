const mysql = require("mysql2");
const express = require("express");
const session = require("express-session");
const flash = require("connect-flash");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();

// Middleware for parsing JSON and URL-encoded form data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Session setup
app.use(session({
    secret: 'your_secret_key', // Change this to a strong random string
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set true if using HTTPS
}));

// Flash middleware must come after session middleware
app.use(flash());

// Middleware to make session accessible in all views
app.use((req, res, next) => {
    res.locals.session = req.session; // Make session accessible
    next();
});

// View engine and static files setup
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "/views"));
app.use(express.static(path.join(__dirname, "public")));


const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'ass',
    password: 'Gautam@1234'
});

connection.connect((err) => {
    if (err) {
        console.log("Error connecting to MySQL", err);
    } else {
        console.log("Connected to MySQL");
    }
});

app.listen(8080, () => {
    console.log("Server listening on port 8080");
});


// Middleware to check if the user is logged in
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        return next(); // User is logged in, proceed to the next middleware/route handler
    } else {
        req.flash("message", "You must log in to access this page.");
        return res.redirect("/login"); // Redirect to login page if not authenticated
    }
}

// Protected route for employee management
app.get("/employees", isAuthenticated, (req, res) => {
    const sql = "SELECT * FROM Employee"; // SQL query to select all employees
    connection.query(sql, (err, results) => {
        if (err) {
            console.log("Error fetching employee data:", err);
            return res.status(500).send("Error fetching employee data");
        }

        // Pass the employee data to the template
        res.render("employee.ejs", { user: req.session.user, employees: results, message: req.flash("message"), success: req.flash("success"), session: req.session });
    });
});

// POST route to add a new employee
app.post("/employees", isAuthenticated, (req, res) => {
    const { name, contactDetails, department, designation, dateOfJoining } = req.body;

    // Check if all fields are filled
    if (!name || !contactDetails || !department || !designation || !dateOfJoining) {
        req.flash("message", "All fields must be filled out");
        return res.redirect("/employees"); // Redirect back to employee form with error message
    }

    if (contactDetails.length !== 10 || !/^\d+$/.test(contactDetails)) {
        req.flash("message", "Contact details must be exactly 10 digits.");
        return res.redirect("/employees");
    }

    // SQL query to insert employee data
    const sql = "INSERT INTO Employee (Name, ContactDetails, Department, Designation, DateOfJoining) VALUES (?, ?, ?, ?, ?)";
    connection.query(sql, [name, contactDetails, department, designation, dateOfJoining], (err, result) => {
        if (err) {
            console.log("Error inserting employee data:", err);
            req.flash("message", "Error inserting employee data");
            return res.status(500).send("Error inserting employee data");
        }

        // Set success flash message after successful insertion
        req.flash("success", "Employee added successfully!");

        // Redirect back to the employee page to show the updated list and flash message
        res.redirect("/employees");
    });
});

// GET route for rendering attendance form with employee list and attendance records
app.get("/attendances", isAuthenticated, (req, res) => {
    const employeeQuery = "SELECT EmployeeID, Name FROM Employee"; // Fetch EmployeeID and Name for dropdown
    const attendanceQuery = "SELECT * FROM Attendance"; // Fetch attendance records

    // Run both queries in parallel
    connection.query(employeeQuery, (err, employees) => {
        if (err) {
            console.log("Error fetching employees:", err);
            return res.status(500).send("Error fetching employees");
        }

        connection.query(attendanceQuery, (err, attendances) => {
            if (err) {
                console.log("Error fetching attendances:", err);
                return res.status(500).send("Error fetching attendances");
            }

            // Render the attendance form and pass employees and attendances to the template
            res.render("attendance.ejs", {
                user: req.session.user,
                employees: employees, // List of employees for the dropdown
                attendances: attendances, // List of attendance records
                message: req.flash("message"),
                success: req.flash("success"),
                session: req.session
            });
        });
    });
});


// POST route for submitting attendance data
app.post("/attendances", isAuthenticated, (req, res) => {
    const { employeeId, date, inTime, outTime } = req.body;

    if (!employeeId || !date || !inTime || !outTime) {
        req.flash("message", "All fields are required.");
        return res.redirect("/attendances");
    }

    const sql = "INSERT INTO Attendance (EmployeeID, Date, InTime, OutTime) VALUES (?, ?, ?, ?)";
    connection.query(sql, [employeeId, date, inTime, outTime], (err, result) => {
        if (err) {
            console.log("Error inserting attendance:", err);
            req.flash("message", "Error inserting attendance data");
            return res.redirect("/attendances");
        }

        req.flash("success", "Attendance added successfully!");
        res.redirect("/attendances");
    });
});

// Protected route for salary
app.get("/salary", isAuthenticated, (req, res) => {
    const employeeQuery = "SELECT EmployeeID, Name FROM Employee"; // Fetch EmployeeID and Name for dropdown
    const sql = "SELECT * FROM Salary"; // Replace with your actual table name and columns

    connection.query(sql, (err, salary) => {
        if (err) {
            console.log("Error fetching salary data:", err);
            return res.status(500).send("Error fetching salary data");
        }

        connection.query(employeeQuery, (err, employees) => {
            if (err) {
                console.log("Error fetching attendances:", err);
                return res.status(500).send("Error fetching attendances");
            }
            // Render salary.ejs and pass the fetched salary data
            res.render("salary.ejs", { user: req.session.user, salary: salary, employees: employees, message: req.flash("message"), success: req.flash("success"), session: req.session });
        });
    });
});

// Protected route for salary insertion
app.post("/salary", isAuthenticated, (req, res) => {
    const { employeeId, basicSalary, deduction, bonus, netSalary } = req.body;

    // SQL query to insert salary data
    const sql = `
        INSERT INTO Salary (EmployeeID, BasicSalary, Deductions, Bonus, NetSalary)
        VALUES (?, ?, ?, ?, ?)
    `;

    // Execute the SQL query
    connection.query(sql, [employeeId, basicSalary, deduction, bonus, netSalary], (err, result) => {
        if (err) {
            console.log("Error inserting salary data:", err);
            req.flash("message", "Error inserting salary data. Please try again.");
            return res.redirect("/salary"); // Redirect back to the salary page
        }

        // Successful insertion message
        req.flash("success", "Salary data added successfully!");
        res.redirect("/salary"); // Redirect back to the salary page
    });
});


// Protected route for advance salary
app.get("/advancesalary", isAuthenticated, (req, res) => {
    const employeeQuery = "SELECT EmployeeID, Name FROM Employee"; // Fetch EmployeeID and Name for dropdown
    const sql = "SELECT * FROM SalaryAdvance"; // Fetch salary advances

    // Query to fetch salary advances
    connection.query(sql, (err, advancesalary) => { // Change this line
        if (err) {
            console.log("Error fetching salary advance data:", err);
            return res.status(500).send("Error fetching salary advance data");
        }

        // Query to fetch employee data
        connection.query(employeeQuery, (err, employees) => {
            if (err) {
                console.log("Error fetching employees:", err);
                return res.status(500).send("Error fetching employees");
            }

            // Render advance.ejs and pass the fetched data
            res.render("advance.ejs", {
                user: req.session.user,
                advancesalary: advancesalary, // Correctly using the fetched advancesalary variable
                employees: employees,
                message: req.flash("message"),
                success: req.flash("success"),
                session: req.session
            });
        });
    });
});

// Protected route for salary insertion
app.post("/advancesalary", isAuthenticated, (req, res) => {
    const { employeeId, amount, requestdate } = req.body;
    console.log("Employee ID:", employeeId);
    console.log("Amount:", amount);
    console.log("Request Date:", requestdate);
    // SQL query to insert salary data with default 'Pending' status
    const sql = `
        INSERT INTO SalaryAdvance (EmployeeID, Amount, RequestDate, Status)
        VALUES (?, ?, ?, 'Pending')
    `;

    // Execute the SQL query
    connection.query(sql, [employeeId, amount, requestdate], (err, result) => {
        if (err) {
            console.log("Error inserting salary data:", err);
            req.flash("message", "Error inserting salary data. Please try again.");
            return res.redirect("/advancesalary"); // Redirect back to the salary page
        }

        // Successful insertion message
        req.flash("success", "Advance salary request submitted successfully!");
        res.redirect("/advancesalary"); // Redirect back to the salary page
    });
});



app.get("/", (req, res) => {
    res.render("index.ejs", { success: req.flash("success"), session: req.session });
});

app.get("/login", (req, res) => {
    res.render("login.ejs", { message: req.flash("message"), success: req.flash("success"), session: req.session });
});

app.post("/login", (req, res) => {
    const { email, password } = req.body;

    // Check if both fields are provided
    if (!email || !password) {
        req.flash("message", "Both email and password are required.");
        return res.redirect("/login");
    }

    // First, check if the user is an admin
    const adminSql = "SELECT * FROM Admin WHERE email = ?"; // Assuming you have an 'email' field in the admin table
    connection.query(adminSql, [email], (err, adminResult) => {
        if (err) {
            console.error("Database error:", err);
            req.flash("message", "An error occurred while trying to log in.");
            return res.redirect("/login");
        }

        // If the user is found in the admin table
        if (adminResult.length > 0) {
            const adminUser = adminResult[0];
            if (adminUser.password === password) {
                // Store admin info in session
                req.session.user = { id: adminUser.adminid, name: adminUser.name, email: adminUser.email }; // Store admin info
                req.session.isAdmin = true; // Mark as admin
                req.flash("success", "Admin login successful! Welcome.");
                return res.redirect("/admin"); // Redirect to the admin dashboard or homepage
            } else {
                req.flash("message", "Invalid email or password.");
                return res.redirect("/login");
            }
        }

        // If not found in admin table, check the signup table for a regular user
        const userSql = "SELECT * FROM signup WHERE email = ?";
        connection.query(userSql, [email], (err, userResult) => {
            if (err) {
                console.error("Database error:", err);
                req.flash("message", "An error occurred while trying to log in.");
                return res.redirect("/login");
            }

            // If user not found
            if (userResult.length === 0) {
                req.flash("message", "Invalid email or password.");
                return res.redirect("/login");
            }

            const user = userResult[0];
            if (user.password === password) {
                // If passwords match, login successful for regular user
                req.session.user = { id: user.id, name: user.name, email: user.email }; // Store user info in session
                req.session.isAdmin = false; // Mark as regular user
                req.flash("success", "Login successful! Welcome.");
                return res.redirect("/"); // Redirect to the employee page or homepage
            } else {
                req.flash("message", "Invalid email or password.");
                return res.redirect("/login");
            }
        });
    });
});

app.get("/signup", (req, res) => {
    res.render("signup", { message: req.flash("error"), session: req.session });
});

// Signup POST route
app.post("/signup", async (req, res) => {
    try {
        const { name, email, password, confirmPassword } = req.body;

        // Check if all fields are provided
        if (!name || !email || !password || !confirmPassword) {
            req.flash("error", "All fields are required.");
            return res.redirect("/signup");
        }

        // Check if password matches confirm password
        if (password !== confirmPassword) {
            req.flash("error", "Password and Confirm Password do not match.");
            return res.redirect("/signup");
        }

        // Check if password length is at least 8 characters
        if (password.length < 8) {
            req.flash("error", "Password must be at least 8 characters long.");
            return res.redirect("/signup");
        }

        // Check if email is already registered
        const checkEmailSql = "SELECT * FROM signup WHERE email = ?";
        connection.query(checkEmailSql, [email], (err, result) => {
            if (err) {
                req.flash("error", "An error occurred. Please try again.");
                return res.redirect("/signup");
            }

            if (result.length > 0) {
                req.flash("error", "This email is already registered.");
                return res.redirect("/signup");
            }

            // Proceed to insert into database if validation passes
            const sql = "INSERT INTO signup(name, email, password) VALUES (?, ?, ?)";
            connection.query(sql, [name, email, password], (err, result) => {
                if (err) {
                    req.flash("error", "An error occurred while signing up.");
                    return res.redirect("/signup");
                } else {
                    req.flash("message", "Signup successful. You can now log in.");
                    res.redirect("/login");
                }
            });
        });

    } catch (error) {
        console.error("Error in signup:", error);
        req.flash("error", "An unexpected error occurred. Please try again.");
        res.redirect("/signup");
    }
});

// Admin Login Route with Validation
app.post('/admin/login', (req, res) => {
    const { email, password } = req.body;

    // Check if all fields are filled
    if (!email || !password) {
        req.flash('message', 'Please fill in all fields.');
        return res.redirect('/login'); // Redirect to login page
    }

    // Validate password length
    if (password.length < 8) {
        req.flash('message', 'Password must be at least 8 characters long.');
        return res.redirect('/login'); // Redirect to login page
    }

    // SQL query to fetch admin by email
    const sql = "SELECT * FROM Admin WHERE Email = ? AND Password = ?";
    connection.query(sql, [email, password], (err, results) => {
        if (err) {
            console.error("Error fetching admin data:", err);
            req.flash('message', 'Error fetching admin data. Please try again.');
            return res.redirect('/login'); // Redirect to login page
        }

        if (results.length === 0) {
            req.flash('message', 'Invalid email or password');
            return res.redirect('/login'); // Redirect to login page
        }

        // Admin found, store session information
        req.session.isAdmin = true;
        req.session.adminEmail = results[0].Email;

        req.flash('success', 'Login successful!');
        return res.redirect('/admin/dashboard'); // Redirect to admin dashboard
    });
});

app.get('/admin/dashboard', (req, res) => {
    if (!req.session.isAdmin) {
        req.flash('message', 'Unauthorized access');
        return res.redirect('/login');
    }

    // Query to count total employees
    const employeeCountQuery = "SELECT COUNT(*) AS total FROM Employee"; // Adjust table name if necessary

    // Query to count pending requests
    const pendingRequestCountQuery = "SELECT COUNT(*) AS total FROM SalaryAdvance WHERE Status = 'Pending'";

    // Query to count approved requests
    const approvedRequestCountQuery = "SELECT COUNT(*) AS total FROM SalaryAdvance WHERE Status = 'Approved'";

    // Query to fetch all salary advance requests
    const salaryAdvanceRequestsQuery = "SELECT * FROM SalaryAdvance";

    // Execute all queries
    connection.query(employeeCountQuery, (err, employeeCountResult) => {
        if (err) {
            console.error("Error fetching total employees:", err);
            req.flash('message', 'Error fetching total employees');
            return res.redirect('/admin/dashboard');
        }

        const totalEmployees = employeeCountResult[0].total;

        connection.query(pendingRequestCountQuery, (err, pendingCountResult) => {
            if (err) {
                console.error("Error fetching pending requests:", err);
                req.flash('message', 'Error fetching pending requests');
                return res.redirect('/admin/dashboard');
            }

            const pendingRequests = pendingCountResult[0].total;

            connection.query(approvedRequestCountQuery, (err, approvedCountResult) => {
                if (err) {
                    console.error("Error fetching approved requests:", err);
                    req.flash('message', 'Error fetching approved requests');
                    return res.redirect('/admin/dashboard');
                }

                const approvedRequests = approvedCountResult[0].total;

                connection.query(salaryAdvanceRequestsQuery, (err, results) => {
                    if (err) {
                        console.error("Error fetching salary advance requests:", err);
                        req.flash('message', 'Error fetching requests');
                        return res.redirect('/admin/dashboard');
                    }
                    
                    // Render the admin dashboard with the required data
                    res.render('admin.ejs', {
                        session: req.session,
                        requests: results,
                        totalEmployees: totalEmployees,
                        pendingRequests: pendingRequests,
                        approvedRequests: approvedRequests,
                        message: req.flash("message"),
                        success: req.flash("success")
                    });
                });
            });
        });
    });
});


app.post('/admin/approve-request/:id', (req, res) => {
    if (!req.session.isAdmin) {
        req.flash('message', 'Unauthorized access');
        return res.redirect('/login');
    }

    const requestId = req.params.id; // Get the request ID from the URL parameter

    // Update the status to 'Approved' where the AdvanceID matches
    const sql = "UPDATE SalaryAdvance SET Status = 'Approved' WHERE AdvanceID = ?";

    connection.query(sql, [requestId], (err, result) => {
        if (err) {
            console.error("Error updating request status:", err);
            req.flash('message', 'Error approving request');
            return res.redirect('/admin/dashboard');
        }

        req.flash('success', 'Request approved successfully');
        res.redirect('/admin/dashboard');
    });
});

app.post('/admin/reject-request/:id', (req, res) => {
    if (!req.session.isAdmin) {
        req.flash('message', 'Unauthorized access');
        return res.redirect('/login');
    }

    const requestId = req.params.id;
    const sql = "UPDATE SalaryAdvance SET status = 'Rejected' WHERE AdvanceID = ?";

    connection.query(sql, [requestId], (err, result) => {
        if (err) {
            console.error("Error updating request status:", err);
            req.flash('message', 'Error rejecting request');
            return res.redirect('/admin/dashboard');
        }
        req.flash('success', 'Request rejected successfully');
        res.redirect('/admin/dashboard');
    });
});
app.get('/admin/logout', (req, res) => {
    console.log(req.session); // Log the current session information

    // Set flash message before destroying the session
    req.flash('success', 'You have successfully logged out.');

    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
            req.flash('message', 'Error logging out. Please try again.');
            return res.redirect('/admin');  // Redirect to admin dashboard if error
        }

        // Redirect to login page after successful logout
        res.redirect('/login');
    });
});

// Route to edit an employee
app.get('/employees/edit/:id', (req, res) => {
    const employeeId = req.params.id;
    const sql = 'SELECT * FROM Employee WHERE EmployeeID = ?';
    connection.query(sql, [employeeId], (err, results) => {
        if (err || results.length === 0) {
            console.error(err);
            req.flash('message', 'Error fetching employee details');
            return res.redirect('/employees');
        }
        res.render('editEmployee.ejs', { employee: results[0],message:req.flash("message"),success:req.flash("success") });
    });
});

// Route to update an employee
app.post('/employees/update/:id', (req, res) => {
    const employeeId = req.params.id;
    const { name, contactDetails, department, designation, dateOfJoining } = req.body;

    const sql = 'UPDATE Employee SET Name = ?, ContactDetails = ?, Department = ?, Designation = ?, DateOfJoining = ? WHERE EmployeeID = ?';
    connection.query(sql, [name, contactDetails, department, designation, dateOfJoining, employeeId], (err) => {
        if (err) {
            console.error(err);
            req.flash('message', 'Error updating employee details');
            return res.redirect('/employees');
        }
        req.flash('success', 'Employee updated successfully');
        res.redirect('/employees');
    });
});

// Route to delete an employee
app.post('/employees/delete/:id', (req, res) => {
    const employeeId = req.params.id;
    const sql = 'DELETE FROM Employee WHERE EmployeeID = ?';
    connection.query(sql, [employeeId], (err) => {
        if (err) {
            console.error(err);
            req.flash('message', 'Error deleting employee');
            return res.redirect('/employees');
        }
        req.flash('success', 'Employee deleted successfully');
        res.redirect('/employees');
    });
});
// Delete an employee by ID
app.delete('/employees/:id', isAuthenticated, (req, res) => {
    const employeeId = req.params.id;

    const deleteQuery = 'DELETE FROM Employee WHERE EmployeeID = ?';
    
    connection.query(deleteQuery, [employeeId], (err, results) => {
        if (err) {
            console.error('Error deleting employee:', err);
            req.flash('message', 'Error deleting employee.'); // Flash message for error
            return res.status(500).json({ success: false, message: 'Error deleting employee.' });
        }

        // Check if any rows were affected
        if (results.affectedRows > 0) {
            req.flash('message', 'Employee deleted successfully.'); // Flash message for success
            return res.json({ success: true, message: 'Employee deleted successfully.' });
        } else {
            req.flash('message', 'Employee not found.'); // Flash message if no rows were affected
            return res.status(404).json({ success: false, message: 'Employee not found.' });
        }
    });
});
